import { createApp } from 'vue'
import App from './App.vue'
import 'highlight.js/styles/vs2015.css'
createApp(App).mount('#app')
