<!-- App.vue -->
<template>
  <div :class="['app', { dark: isDarkMode }]">
    <AppHeader @toggle-dark-mode="toggleDarkMode" :isDarkMode="isDarkMode" />

    <main class="main-content">
      <InfoText />

      <Toolbar
        v-model:selectedColor="selectedColor"
        @format="wrapSelection"
        @block-format="insertLinePrefix"
        @insert-link="insertLink"
        @insert-image="insertImage"
      />

      <section class="editor-preview-wrapper">
        <Editor v-model="markdownText" ref="editorRef" />

        <section class="preview" v-html="htmlPreview"></section>
      </section>

      <ConvertButton :editorRef="editorRef" :markdown="markdownText" />
    </main>

    <AppFooter />
  </div>
</template>

<script setup>
import { ref, computed, nextTick } from 'vue'
import hljs from 'highlight.js'
import 'highlight.js/styles/github-dark.css'

import AppHeader from './components/AppHeader.vue'
import AppFooter from './components/AppFooter.vue'
import InfoText from './components/InfoText.vue'
import Toolbar from './components/Toolbar.vue'
import Editor from './components/Editor.vue'
import ConvertButton from './components/ConvertButton.vue'

import { marked } from 'marked'

const isDarkMode = ref(false)
function toggleDarkMode() {
  isDarkMode.value = !isDarkMode.value
}

const selectedColor = ref('#000000')
const markdownText = ref('')
const editorRef = ref(null)

function wrapSelection({ before, after }) {
  const textarea = editorRef.value?.$el
  if (!textarea) return

  const start = textarea.selectionStart
  const end = textarea.selectionEnd
  const selected = textarea.value.slice(start, end)

  const isAlreadyWrapped = selected.startsWith(before) && selected.endsWith(after)

  const newText = isAlreadyWrapped
    ? selected.slice(before.length, selected.length - after.length)
    : `${before}${selected}${after}`

  const updated = textarea.value.slice(0, start) + newText + textarea.value.slice(end)

  markdownText.value = updated
  nextTick(() => {
    textarea.focus()
    const cursorOffset = isAlreadyWrapped ? -before.length : before.length
    textarea.setSelectionRange(start + cursorOffset, end + cursorOffset)
  })
}

function insertLinePrefix({ prefix }) {
  const textarea = editorRef.value?.$el
  if (!textarea) return

  const start = textarea.selectionStart
  const end = textarea.selectionEnd
  const before = textarea.value.slice(0, start)
  const selection = textarea.value.slice(start, end)
  const after = textarea.value.slice(end)

  const lines = selection.split('\n')
  const allPrefixed = lines.every((line) => line.startsWith(prefix))

  const updatedSelection = allPrefixed
    ? lines.map((line) => line.replace(prefix, '')).join('\n')
    : lines.map((line) => `${prefix}${line}`).join('\n')

  markdownText.value = before + updatedSelection + after
  nextTick(() => {
    textarea.focus()
    textarea.setSelectionRange(start, start + updatedSelection.length)
  })
}

function insertLink({ url }) {
  wrapSelection({ before: '[', after: `](${url})` })
}

function insertImage({ url }) {
  wrapSelection({ before: '![', after: `](${url})` })
}

const htmlPreview = computed(() => {
  const rawHtml = marked.parse(markdownText.value)
  const temp = document.createElement('div')
  temp.innerHTML = rawHtml
  temp.querySelectorAll('pre code').forEach((block) => {
    hljs.highlightElement(block)
  })
  return temp.innerHTML
})
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Fira+Code&display=swap');

.app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  background-color: #1e1e1e;
  color: #dcdcdc;
  font-family: 'Fira Code', monospace;
}

.main-content {
  flex: 1;
  max-width: 960px;
  margin: 1.5rem auto;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.editor-preview-wrapper {
  display: flex;
  gap: 1rem;
  height: 400px;
}

.editor-preview-wrapper > * {
  flex: 1;
  overflow: auto;
  border-radius: 8px;
}

.preview {
  background: #1e1e1e;
  border: 1px solid #333;
  padding: 1rem;
  color: #ddd;
  overflow-y: auto;
  font-family: 'Fira Code', monospace;
}

.preview pre {
  background-color: #262626;
  padding: 0.75rem;
  border-radius: 6px;
  overflow-x: auto;
}

.preview code {
  font-family: 'Fira Code', monospace;
  font-size: 0.95rem;
  color: #fffbf1;
}
</style>
