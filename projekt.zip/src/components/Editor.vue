<template>
  <div
    class="editor"
    contenteditable="true"
    :inner-text="localValue"
    @input="onInput"
    ref="editorEl"
  ></div>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps(['modelValue'])
const emit = defineEmits(['update:modelValue'])

const editorEl = ref(null)
const localValue = ref(props.modelValue || '')

// Editor-Text aktualisieren, wenn modelValue sich von außen ändert
watch(
  () => props.modelValue,
  (newVal) => {
    if (newVal !== editorEl.value?.innerText) {
      editorEl.value.innerText = newVal
      localValue.value = newVal
    }
  },
)

// Textausgabe bei Benutzereingabe
function onInput(event) {
  const text = event.target.innerText
  emit('update:modelValue', text)
  localValue.value = text
}
</script>

<style scoped>
.editor {
  background: #fff;
  border: 1px solid #ccc;
  padding: 1rem;
  border-radius: 6px;
  height: 100%;
  width: 100%;
  overflow-y: auto;
  font-family: monospace;
  box-sizing: border-box;
}

.dark .editor {
  background: #1e1e1e;
  color: #eee;
  border-color: #444;
}
</style>
