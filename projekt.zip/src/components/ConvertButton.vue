<template>
  <button class="convert-button" @click="convertAndCopy">Convert & Copy</button>
</template>

<script setup>
const props = defineProps({
  editorRef: Object,
  markdown: String,
})

function convertAndCopy() {
  // Beispiel: Markdown in HTML konvertieren und in Clipboard kopieren
  if (!props.markdown) return

  const html = props.markdown // Hier z.B. kannst du mit marked konvertieren, falls gewünscht

  navigator.clipboard.writeText(html).then(() => {
    alert('Konvertierter Text in die Zwischenablage kopiert!')
  })
}
</script>

<style scoped>
.convert-button {
  background-color: #3f51b5;
  color: white;
  border: none;
  padding: 0.6rem 1.2rem;
  font-size: 1rem;
  font-weight: 600;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.25s ease;
  margin-top: 1rem;
  align-self: flex-start;
}

.convert-button:hover {
  background-color: #303f9f;
}
</style>
