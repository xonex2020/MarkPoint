<template>
  <section class="info">
    <p class="info-text">
      Dieses Tool hilft dir, Markdown-Text einfach in HTML umzuwandeln, das
      <strong>in SharePoint-Webparts</strong> wie "Text" oder "Code-Snippet" eingefügt werden
      kann.<br />
      Gib deinen Text im Markdown-Format ein, verwende die Toolbar für Formatierungen, und kopiere
      anschließend das HTML über den
      <em>Convert & Copy</em>-Button.<br />
      📋 <strong>Danach:</strong> Wechsle zu SharePoint, füge ein Text-Webpart ein, klicke auf
      <em>&lt;Code anzeigen&gt;</em> (&#x3C;&#x2F;&#x3E;) und füge dort den kopierten HTML-Code ein.
    </p>
  </section>
</template>

<style scoped>
.info-text {
  font-size: 1rem;
  line-height: 1.4;
  margin-bottom: 1rem;
  color: var(--text-color);
}
</style>
