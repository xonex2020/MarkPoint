<template>
  <footer class="app-footer">
    <small> © 2025 Markdown Editor &mdash; built with Vue 3 &amp; ❤️ </small>
  </footer>
</template>

<script setup></script>

<style scoped>
.app-footer {
  text-align: center;
  padding: 1rem 2rem;
  background: #252532;
  color: #888ca3;
  font-family: 'Inter', sans-serif;
  font-size: 0.875rem;
  user-select: none;
  box-shadow: inset 0 1px 0 rgb(255 255 255 / 0.05);
}
</style>
