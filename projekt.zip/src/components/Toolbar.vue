<template>
  <div class="toolbar">
    <button @click="emitWrap('**', '**')" title="Fett"><b>B</b></button>
    <button @click="emitWrap('_', '_')" title="Kursiv"><i>I</i></button>
    <button @click="emitWrap('__', '__')" title="Unterstrichen"><u>U</u></button>
    <button @click="emitWrap('~~', '~~')" title="Durchgestrichen"><s>S</s></button>

    <div class="dropdown" @mouseleave="close('heading')">
      <button @click="toggle('heading')">Überschrift ▼</button>
      <div v-if="open === 'heading'" class="dropdown-menu">
        <button @click="emitPrefix('# ')">H1</button>
        <button @click="emitPrefix('## ')">H2</button>
        <button @click="emitPrefix('### ')">H3</button>
      </div>
    </div>

    <div class="dropdown" @mouseleave="close('list')">
      <button @click="toggle('list')">Liste ▼</button>
      <div v-if="open === 'list'" class="dropdown-menu">
        <button @click="emitPrefix('- ')">• Ungeordnet</button>
        <button @click="emitPrefix('1. ')">1. Geordnet</button>
      </div>
    </div>

    <button @click="emitPrefix('> ')" title="Zitat">❝</button>
    <button @click="emitWrap('```\\n', '\\n```')" title="Codeblock">Code</button>

    <button @click="emitLink()" title="Link">🔗</button>
    <button @click="emitImage()" title="Bild">🖼️</button>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const emit = defineEmits(['format', 'block-format', 'insert-link', 'insert-image'])

const open = ref(null)

function toggle(name) {
  open.value = open.value === name ? null : name
}
function close(name) {
  if (open.value === name) open.value = null
}

function emitWrap(before, after) {
  emit('format', { before, after })
}

function emitPrefix(prefix) {
  emit('block-format', { prefix })
}

function emitLink() {
  const url = prompt('Link-URL eingeben')
  if (url) emit('insert-link', { url })
}

function emitImage() {
  const url = prompt('Bild-URL eingeben')
  if (url) emit('insert-image', { url })
}
</script>

<style scoped>
.toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 0.3rem;
  padding: 0.5rem;
  background: #f5f5f5;
  border-radius: 5px;
  font-size: 0.9rem;
}

.toolbar button {
  cursor: pointer;
  border: none;
  background: white;
  border-radius: 3px;
  padding: 0.3rem 0.6rem;
  transition: background-color 0.15s ease;
}

.toolbar button:hover,
.toolbar button.active {
  background-color: #d1e0ff;
}

.dropdown {
  position: relative;
}

.dropdown-menu {
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 100;
  background: white;
  border: 1px solid #ccc;
  padding: 0.25rem 0;
  box-shadow: 0 4px 6px rgb(0 0 0 / 0.1);
}

.dropdown-menu button {
  display: block;
  width: 100%;
  padding: 0.4rem 0.6rem;
  background: none;
  border: none;
  text-align: left;
  cursor: pointer;
}

.dropdown-menu button:hover {
  background-color: #e0e7ff;
}
</style>
